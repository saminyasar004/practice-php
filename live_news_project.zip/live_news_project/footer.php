<div id ="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <span>© Copyright 2020 News Site | Powered by <a href="https://www.youtube.com/nirobhasan">Nirob Hasan</a></span>
            </div>
        </div>
    </div>
</div>
</body>
</html>
